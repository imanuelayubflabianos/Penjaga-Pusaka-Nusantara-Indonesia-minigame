using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Setingan Pergerakan")]
    [SerializeField] private float kecepatan = 5f;

    [Header("Komponen")]
    [SerializeField] private Animator animator;
    [SerializeField] private float jarakAmbilBarang = 1.5f;  // Radius untuk mengambil barang

    private Rigidbody2D rb;
    private Vector2 inputGerak;
    private Vector2 terakhirInputGerak = Vector2.down;
    private bool sedangAmbilBarang = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        if (animator == null)
        {
            animator = GetComponent<Animator>();
        }
    }

    void Update()
    {
        MemprosesInput();
        JalankanAnimasi();

        // Contoh input untuk ambil/taruh barang (tekan E)
        if (Input.GetKeyDown(KeyCode.E))
        {
            Debug.Log("Tombol E ditekan");
            AmbilBarang();
        }
    }

    void FixedUpdate()
    {
        rb.velocity = inputGerak * kecepatan;
    }

    void MemprosesInput()
    {
        // Jika sedang ambil barang, set input gerak ke 0
        if (sedangAmbilBarang)
        {
            inputGerak = Vector2.zero;
            return;
        }

        inputGerak.x = Input.GetAxisRaw("Horizontal");
        inputGerak.y = Input.GetAxisRaw("Vertical");

        if (inputGerak.sqrMagnitude > 0.01f)
        {
            terakhirInputGerak = inputGerak.normalized;
        }

        inputGerak.Normalize();
    }

    void JalankanAnimasi()
    {
        float jarakJalan = inputGerak.sqrMagnitude;

        animator.SetFloat("DistanceRun", jarakJalan);

        if (jarakJalan > 0.01f)
        {
            animator.SetFloat("RunX", inputGerak.x);
            animator.SetFloat("RunY", inputGerak.y);
            animator.SetFloat("PosisiTerakhirX", inputGerak.x);
            animator.SetFloat("PosisiTerakhirY", inputGerak.y);
        }
        else
        {
            animator.SetFloat("RunX", terakhirInputGerak.x);
            animator.SetFloat("RunY", terakhirInputGerak.y);
            animator.SetFloat("PosisiTerakhirX", terakhirInputGerak.x);
            animator.SetFloat("PosisiTerakhirY", terakhirInputGerak.y);
        }
    }

    public void AmbilBarang()
    {
        Debug.Log("Mencoba mengambil barang...");
        // Cari objek terdekat dengan tag "BarangBisaDiambil"
        Collider2D[] barangDiDekat = Physics2D.OverlapCircleAll(transform.position, jarakAmbilBarang);
        Debug.Log($"Menemukan {barangDiDekat.Length} objek di sekitar");
        GameObject barangTerdekat = null;
        float jarakTerdekat = jarakAmbilBarang;

        foreach (Collider2D collider in barangDiDekat)
        {
            if (collider.CompareTag("BarangBisaDiambil"))
            {
                float jarak = Vector2.Distance(transform.position, collider.transform.position);
                if (jarak < jarakTerdekat)
                {
                    jarakTerdekat = jarak;
                    barangTerdekat = collider.gameObject;
                }
            }
        }

        // Jika menemukan barang yang bisa diambil
        if (barangTerdekat != null)
        {
            sedangAmbilBarang = true;
            animator.SetTrigger("AmbilBarang");

            // Tambah skor (default +1) lalu hapus objek
            if (ScoreManager.Instance != null)
            {
                ScoreManager.Instance.TambahSkor(1);
            }
            else
            {
                Debug.LogWarning("ScoreManager tidak ditemukan di scene. Tambahkan GameObject dengan komponen ScoreManager untuk menyimpan skor.");
            }

            // Destroy objek yang diambil
            Destroy(barangTerdekat);

            // Tunggu sebentar lalu reset flag (sesuaikan dengan durasi animasi)
            Invoke("SelesaiAmbilBarang", 1f);
        }
    }

    private void SelesaiAmbilBarang()
    {
        sedangAmbilBarang = false;
    }

    // Optional: Visualisasi radius pengambilan barang di editor
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, jarakAmbilBarang);
    }
}