using UnityEngine;

public class PembuatObjek : MonoBehaviour
{
    [Header("Pengaturan Objek")]
    [SerializeField] private GameObject[] daftarObjekYangBisaDiambil;

    [Header("Pengaturan Spawn")]
    [SerializeField] private float jarakSpawnX = 5f;
    [SerializeField] private float jarakSpawnY = 5f;
    [SerializeField] private int jumlahObjekAwal = 5;

    private Transform pemain;
    private bool sudahSpawn = false;

    private void Awake()
    {
        // Cegah duplicate PembuatObjek
        PembuatObjek[] semua = FindObjectsOfType<PembuatObjek>();
        if (semua.Length > 1)
        {
            Destroy(gameObject);
            return;
        }
    }

    private void Start()
    {
        pemain = GameObject.FindGameObjectWithTag("Player")?.transform;

        if (!sudahSpawn)
        {
            SpawnObjekAwal();
            sudahSpawn = true;
        }
    }

    private void SpawnObjekAwal()
    {
        if (daftarObjekYangBisaDiambil.Length == 0)
        {
            Debug.LogWarning("Prefab kosong, isi dulu woi");
            return;
        }

        for (int i = 0; i < jumlahObjekAwal; i++)
        {
            BuatObjekBaru();
        }
    }

    private void BuatObjekBaru()
    {
        Vector2 posisiSpawn = HitungPosisiSpawnAcak();
        int indeks = Random.Range(0, daftarObjekYangBisaDiambil.Length);

        GameObject obj = Instantiate(
            daftarObjekYangBisaDiambil[indeks],
            posisiSpawn,
            Quaternion.identity
        );

        obj.name = "Item_" + Time.time;
    }

    private Vector2 HitungPosisiSpawnAcak()
    {
        Vector2 posisi;

        do
        {
            float x = Random.Range(-jarakSpawnX, jarakSpawnX);
            float y = Random.Range(-jarakSpawnY, jarakSpawnY);
            posisi = new Vector2(x, y);

        } while (pemain != null && Vector2.Distance(posisi, pemain.position) < 2f);

        return posisi;
    }
}