using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance { get; private set; }

    [Header("Pengaturan Skor")]
    public int skor = 0;

    [Header("Pengaturan Menang")]
    public int targetSkor = 5;
    public GameObject teksMenang;

    private void Awake()
    {
        // Singleton biar gak duplicate
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void TambahSkor(int jumlah)
    {
        skor += jumlah;
        Debug.Log("Skor sekarang: " + skor);

        // CEK MENANG
        if (skor >= targetSkor)
        {
            Menang();
        }
    }

    private void Menang()
    {
        Debug.Log("MENANG!");

        if (teksMenang != null)
        {
            teksMenang.SetActive(true);
        }
        else
        {
            Debug.LogWarning("Teks Menang belum di-assign di Inspector!");
        }
    }

    public int DapatkanSkor()
    {
        return skor;
    }
}