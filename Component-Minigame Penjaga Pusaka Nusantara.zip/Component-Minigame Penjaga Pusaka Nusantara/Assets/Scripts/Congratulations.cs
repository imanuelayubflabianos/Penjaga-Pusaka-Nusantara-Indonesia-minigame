using UnityEngine;

public class GameManager : MonoBehaviour
{
    public int totalItem;
    private int itemDiambil = 10;

    public GameObject teksMenang;

    public void AmbilItem()
    {
        itemDiambil++;

        if (itemDiambil >= totalItem)
        {
            teksMenang.SetActive(true);
        }
    }
}