using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// Import SceneManagement untuk mengelola pergantian scene
using UnityEngine.SceneManagement;

public class ButtonManager : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    // Method public untuk berpindah ke scene game
    public void GameStart()
    {
        SceneManager.LoadScene("GameScene");
    }
}
