using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Menampilkan skor di layar.
/// Pasang skrip ini pada GameObject (mis. pada ScoreManager) dan hubungkan Text UI.
/// Jika tidak terhubung, skrip akan mencari GameObject bernama "SkorText".
/// </summary>
public class ScoreUI : MonoBehaviour
{
    [Header("Komponen UI")]
    [SerializeField] private TMPro.TextMeshProUGUI teksSkor;
    [SerializeField] private string prefix = "Skor: ";

    private void Awake()
    {
        if (teksSkor == null)
        {
            GameObject go = GameObject.Find("SkorText");
            if (go != null)
            {
                teksSkor = go.GetComponent<TMPro.TextMeshProUGUI>();
            }
        }

        if (teksSkor == null)
        {
            Debug.LogWarning("ScoreUI: Text UI tidak ditemukan. Buat GameObject UI Text bernama 'SkorText' atau drag Text ke komponen ini.");
            enabled = false;
        }
    }

    private void Update()
    {
        if (ScoreManager.Instance == null || teksSkor == null) return;
        teksSkor.text = prefix + ScoreManager.Instance.DapatkanSkor();
    }
}